package de.dhbw.java.uebung09.fahrzeuge.aufgabe3;

public abstract class JuristischePerson extends Person
{
    private String name;

    public JuristischePerson(String name)
    {
        super();
        this.name = name;
    }

    @Override
    public String toString()
    {
        return this.name;
    }
}
