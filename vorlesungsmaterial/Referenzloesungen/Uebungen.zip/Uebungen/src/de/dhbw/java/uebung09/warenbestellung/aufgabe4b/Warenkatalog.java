package de.dhbw.java.uebung09.warenbestellung.aufgabe4b;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class Warenkatalog
{
    private Map waren;
    
    public Warenkatalog()
    {
        this.waren = new TreeMap();
    }
    
    public void fuegeWareEin(Ware ware)
    {
        this.waren.put(ware.getNummer(), ware);
    }
    
    public void entferneWare(String warennummer)
    {
        this.waren.remove(warennummer);
    }
    
    public Ware gibWare(String warennummer)
    {
        return (Ware) this.waren.get(warennummer);
    }
    
    public int anzahl()
    {
        return this.waren.size();
    }
    
    public Collection alleWaren()
    {
        return this.waren.values();
    }
    
    public Collection alleWarennummern()
    {
        return this.waren.keySet();
    }
    
    // Hinweis: das ist keine schöne Lösung! Sie enthält viel zu viel Redundanzen.
    // Wir werden das in eine der Folgeaufgaben lösen.
    public Collection alleWarenNachBezeichnung()
    {
        TreeSet warenNachBezeichnung = new TreeSet(new WareBezeichnungComparator());
        warenNachBezeichnung.addAll(alleWaren());
        return warenNachBezeichnung;
    }
    
    public Collection alleWarenNachPreis()
    {
        TreeSet warenNachBezeichnung = new TreeSet(new WarePreisComparator());
        warenNachBezeichnung.addAll(alleWaren());
        return warenNachBezeichnung; 
    }
    
    public void zeigeKatalog()
    {
        for (Object wareObj : alleWaren())
        {
            Ware ware = (Ware) wareObj;
            
            System.out.printf("%12s %15s %8.2f EUR%n", ware.getNormalisierteNummer(), ware.getBezeichnung(), ware.getPreis());
        }
    }
    
    // das ist der häßlichste Teil mit VIEL Code-Wiederholung. Wird wieder abgeschafft, aber derzeit ist es das Mittel der Wahl.
    public void zeigeKatalogNachBezeichnung()
    {
        for (Object wareObj : alleWarenNachBezeichnung())
        {
            Ware ware = (Ware) wareObj;
            
            System.out.printf("%12s %15s %8.2f EUR%n", ware.getNormalisierteNummer(), ware.getBezeichnung(), ware.getPreis());
        }
    }
    
    public void zeigeKatalogNachPreis()
    {
        for (Object wareObj : alleWarenNachPreis())
        {
            Ware ware = (Ware) wareObj;
            
            System.out.printf("%12s %15s %8.2f EUR%n", ware.getNormalisierteNummer(), ware.getBezeichnung(), ware.getPreis());
        }
    }
}
