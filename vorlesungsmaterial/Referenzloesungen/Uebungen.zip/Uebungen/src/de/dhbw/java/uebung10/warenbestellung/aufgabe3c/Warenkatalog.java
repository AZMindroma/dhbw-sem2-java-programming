package de.dhbw.java.uebung10.warenbestellung.aufgabe3c;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class Warenkatalog implements Iterable<Ware>
{
    private Map<String, Ware> waren;
    private Sortierkriterium kriterium;

    public Warenkatalog()
    {
        this.waren = new TreeMap<>();
        this.kriterium = Sortierkriterium.NACH_NUMMER; // Default
    }

    public void fuegeWareEin(Ware ware)
    {
        this.waren.put(ware.getNummer(), ware);
    }

    public void entferneWare(String warennummer)
    {
        this.waren.remove(warennummer);
    }

    public Ware gibWare(String warennummer)
    {
        return this.waren.get(warennummer);
    }

    public int anzahl()
    {
        return this.waren.size();
    }
    
    public void setKriterium(Sortierkriterium kriterium)
    {
        this.kriterium = kriterium;
    }
    
    @Override
    public Iterator<Ware> iterator()
    {
        // Das wäre eine "naive", aber effektive Lösung des Problems
        switch(this.kriterium)
        {
            case NACH_BEZEICHNUNG: return alleWarenNachBezeichnung().iterator();
            case NACH_PREIS: return alleWarenNachPreis().iterator();
            case NACH_NUMMER: return alleWaren().iterator();
            default:
                throw new IllegalStateException("Ein ungültiges oder bisher unbekanntes Sortierkriterium wurde verwendet.");
        }
    }

    public Collection<Ware> alleWaren()
    {
        return this.waren.values();
    }

    public Collection<String> alleWarennummern()
    {
        return this.waren.keySet();
    }

    public Collection<Ware> alleWarenNachBezeichnung()
    {
        TreeSet<Ware> warenNachBezeichnung = new TreeSet<>(new WareBezeichnungComparator());
        warenNachBezeichnung.addAll(alleWaren());
        return warenNachBezeichnung;
    }

    public Collection<Ware> alleWarenNachPreis()
    {
        TreeSet<Ware> warenNachBezeichnung = new TreeSet<>(new WarePreisComparator());
        warenNachBezeichnung.addAll(alleWaren());
        return warenNachBezeichnung;
    }

    @Deprecated
    public void zeigeKatalog()
    {
        for (Ware ware : alleWaren())
        {
            System.out.println(ware);
        }
    }

    @Deprecated
    public void zeigeKatalogNachBezeichnung()
    {
        for (Ware ware : alleWarenNachBezeichnung())
        {
            System.out.println(ware);
        }
    }

    @Deprecated
    public void zeigeKatalogNachPreis()
    {
        for (Ware ware : alleWarenNachPreis())
        {
            System.out.println(ware);
        }
    }
}
