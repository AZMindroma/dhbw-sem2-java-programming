package de.dhbw.java.uebung06.fahrzeuge.aufgabe3;

public class Firma extends Fahrzeughalter
{
    private String name;

    public Firma(String name)
    {
        super();
        this.name = name;
    }

    @Override
    public String toString()
    {
        return String.format("Firma %s", this.name);
    }
}
