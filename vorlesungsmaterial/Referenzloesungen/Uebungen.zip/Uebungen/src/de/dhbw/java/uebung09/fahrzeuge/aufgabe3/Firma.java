package de.dhbw.java.uebung09.fahrzeuge.aufgabe3;

import java.util.Collection;

public class Firma extends JuristischePerson implements Fahrzeughalter
{
    private Fahrzeugpark park;
    
    public Firma(String name)
    {
        super(name);
        this.park = new Fahrzeugpark();
    }
    
    @Override
    public String toString()
    {
        return "Firma " + super.toString();
    }
    
    @Override
    public Collection getFahrzeuge()
    {
        return this.park.getAll();
    }
    
    @Override
    public void addFahrzeug(Fahrzeug fahrzeug)
    {
        this.park.add(fahrzeug);
    }
}
