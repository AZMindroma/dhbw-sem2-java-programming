package de.dhbw.java.uebung11.warenbestellung.aufgabe2de;

public enum Sortierkriterium
{
    NACH_NUMMER, NACH_BEZEICHNUNG, NACH_PREIS;
}
