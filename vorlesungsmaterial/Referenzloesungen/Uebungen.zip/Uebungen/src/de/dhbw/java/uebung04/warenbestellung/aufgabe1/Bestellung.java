package de.dhbw.java.uebung04.warenbestellung.aufgabe1;

public class Bestellung
{
    private Bestellposition[] positionen;
    private Kunde             kunde;

    public Bestellung(Kunde kunde)
    {
        this.kunde = kunde;
        this.positionen = new Bestellposition[20]; // erst einmal nur 20 Positionen möglich
    }

    public void nimmAuf(Bestellposition pos)
    {
        for (int i = 0; i < this.positionen.length; i++) // suche eine freie Position
        {
            if (this.positionen[i] == null) // noch nichts drin
            {
                this.positionen[i] = pos; // dann einfüllen
                return; // und fertig, auf keinen Fall Schleife weiterführen
                // alternativ: break;
            }
        }

    }

    public void zeigeAn()
    {
        System.out.print("Bestellung von " + kunde.getVorname() + " " + kunde.getNachname() + " (KN " + kunde.getNummer() + ")");

        if (this.kunde.getBekommtRabatt())
        {
            System.out.print(" mit " + Kundenrabatt.getRabattsatz() * 100 + "% Kundenrabatt");
        }

        System.out.println();

        for (Bestellposition bestellposition : this.positionen)
        {
            if (bestellposition == null)
            {
                return; // ab hier gibt es nichts mehr zu tun
            }

            // Hilfsvariablen, damit die Darstellungssyntax nicht zu lang wird
            Ware w = bestellposition.getWare();
            int menge = bestellposition.getMenge();

            System.out.print(w.getNummer() + " " + w.getBezeichnung() + ", Listenpreis: " + w.getPreis() + " EUR,"); 
            if (this.kunde.getBekommtRabatt())
            {
                System.out.print(" Kundenpreis: " + Kundenrabatt.berechneRabattpreis(w.getPreis()) + " EUR,");
            }
            System.out.println(" Menge: " + menge);
        }
    }
}
