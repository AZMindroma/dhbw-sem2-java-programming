package de.dhbw.java.uebung09.fahrzeuge.aufgabe3;

import java.util.Collection;

public interface Fahrzeughalter
{
    void addFahrzeug(Fahrzeug fahrzeug);

    Collection getFahrzeuge();
}
