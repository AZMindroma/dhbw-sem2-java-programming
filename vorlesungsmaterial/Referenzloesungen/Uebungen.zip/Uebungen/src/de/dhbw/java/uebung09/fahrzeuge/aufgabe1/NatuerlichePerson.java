package de.dhbw.java.uebung09.fahrzeuge.aufgabe1;

public class NatuerlichePerson extends Person implements Fahrzeughalter
{
    private String vorname;
    private String nachname;
    private Fahrzeugpark park;

    public NatuerlichePerson(String vorname, String nachname)
    {
        super();
        this.vorname = vorname;
        this.nachname = nachname;
        this.park = new Fahrzeugpark();
    }

    @Override
    public String toString()
    {
        return String.format("%s %s", this.vorname, this.nachname);
    }
    
    @Override
    public Fahrzeug[] getFahrzeuge()
    {
        return this.park.getAll();
    }
    
    @Override
    public void addFahrzeug(Fahrzeug fahrzeug)
    {
        this.park.add(fahrzeug);
    }
}
