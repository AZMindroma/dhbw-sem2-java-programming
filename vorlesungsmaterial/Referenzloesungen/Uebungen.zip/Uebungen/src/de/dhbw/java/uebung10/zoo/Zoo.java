package de.dhbw.java.uebung10.zoo;

import java.util.ArrayList;
import java.util.List;

public class Zoo<T extends Tier>
{
    private List<T> tiere;
    
    public Zoo()
    {
        this.tiere = new ArrayList<T>();
    }
    
    public void fuegeHinzu(T tier)
    {
        this.tiere.add(tier);
    }

    public void schreibeAufListe(List<? super T> liste)
    {
        liste.addAll(tiere);
    }
}
