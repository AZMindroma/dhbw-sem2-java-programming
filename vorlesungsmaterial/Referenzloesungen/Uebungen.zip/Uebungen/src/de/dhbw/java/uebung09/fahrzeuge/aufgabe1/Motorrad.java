package de.dhbw.java.uebung09.fahrzeuge.aufgabe1;

public class Motorrad extends Fahrzeug
{
    public Motorrad(Fahrzeughalter halter)
    {
        super(halter, "Motorrad", 2);
    }
}
