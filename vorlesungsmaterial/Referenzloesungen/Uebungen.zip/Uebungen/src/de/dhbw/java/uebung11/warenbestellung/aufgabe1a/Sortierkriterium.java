package de.dhbw.java.uebung11.warenbestellung.aufgabe1a;

public enum Sortierkriterium
{
    NACH_NUMMER, NACH_BEZEICHNUNG, NACH_PREIS;
}
