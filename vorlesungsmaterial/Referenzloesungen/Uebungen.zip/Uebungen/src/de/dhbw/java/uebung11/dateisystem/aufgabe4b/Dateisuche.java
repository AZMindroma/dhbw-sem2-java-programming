package de.dhbw.java.uebung11.dateisystem.aufgabe4b;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Dateisuche
{
    public static void main(String[] args)
    {
        if (args.length != 2)
        {
            Dateisuche.printUsage();
            return;
        }

        String startverzeichnis = args[0];
        String dateiendung = args[1];

        Dateisuche.suche(startverzeichnis, dateiendung);
    }

    private static void suche(String startverzeichnis, String dateiendung)
    {
        Path file = Paths.get(startverzeichnis).toAbsolutePath();

        if (!Files.exists(file) || !Files.isDirectory(file))
        {
            return;
        }

        try
        {
            Files.list(file).filter(f -> Files.isDirectory(f)).forEach(p -> Dateisuche.suche(p.toString(), dateiendung));
            Files.list(file).filter(f -> f.getFileName().toString().endsWith(dateiendung)).map(f -> f.toString()).forEach(s -> System.out.println(s));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private static void printUsage()
    {
        System.out.println("Fehlende oder falsche Parameter.");
        System.out.println("Die Anwendung wird so gestartet:");
        System.out.println("  java -jar dateisuche.jar <startpfad> <dateiendung>");
    }
}
