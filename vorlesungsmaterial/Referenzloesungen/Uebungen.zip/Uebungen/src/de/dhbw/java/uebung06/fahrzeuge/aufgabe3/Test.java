package de.dhbw.java.uebung06.fahrzeuge.aufgabe3;

public class Test
{
    public static void main(String[] args)
    {
        Firma dagobert = new Firma("Dagobert Inc.");
        Person donald = new Person("Donald","Duck");
        
        Pkw p = new Pkw(dagobert, 4, 5);
        Motorrad m = new Motorrad(donald);
        
        Fahrzeug[] fahrzeuge = { p, m };
        
        for (Fahrzeug fahrzeug : fahrzeuge)
        {
            Fahrzeughalter halter = fahrzeug.getHalter();
            System.out.printf("Das Fahrzeug von %s ist ein %s.%n", halter, halter.getFahrzeug());
            System.out.printf("Dieses Fahrzeug ist ein %s. Es gehört %s.%n", fahrzeug, halter);
            System.out.println();
        }
    }
}
