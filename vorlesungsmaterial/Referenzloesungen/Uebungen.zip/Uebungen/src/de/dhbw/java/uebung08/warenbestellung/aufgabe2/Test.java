package de.dhbw.java.uebung08.warenbestellung.aufgabe2;

public class Test
{
    public static void main(String[] args)
    {
        AenderbareWare w = new AenderbareWare("01019010", "Hammer", 19.00);
        System.out.printf("%8s %20s %6.2f%n", w.getNummer(), w.getBezeichnung(), w.getPreis());

        w.setBezeichnung("sehr teurer Hammer");
        w.setPreis(88.0);
        System.out.printf("%8s %20s %6.2f%n", w.getNummer(), w.getBezeichnung(), w.getPreis());
    }
}
