package de.dhbw.java.uebung08.warenbestellung.aufgabe5;

public class BestellException extends Exception
{
    private Bestellposition betroffenePosition;

    public BestellException(Bestellposition betroffenePosition, int fuellgrad)
    {
        super("Die Bestellung enthält bereits " + fuellgrad + " Bestellpositionen.");
        this.betroffenePosition = betroffenePosition;
    }

    public Bestellposition getBetroffenePosition()
    {
        return this.betroffenePosition;
    }
}
