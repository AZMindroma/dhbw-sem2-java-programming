package de.dhbw.java.uebung08.warenbestellung.aufgabe41;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ware
{
    private static final Pattern NUMMER_MUSTER = Pattern.compile("(\\d{4})(\\d{4})");

    private String               nummer;
    private String               bezeichnung;
    private double               preis;

    public Ware(String nummer, String bezeichnung, double preis)
    {
        super();

        if (nummer == null || "".equals(nummer))
        {
            throw new IllegalArgumentException("Warennummer muss einen gültigen Inhalt haben.");
        }

        if (bezeichnung == null || "".equals(bezeichnung))
        {
            throw new IllegalArgumentException("Bezeichnung muss einen gültigen Inhalt haben.");
        }

        this.nummer = nummer;
        this.bezeichnung = bezeichnung;

        // Setter macht Überwachung
        this.setPreis(preis);
    }

    public double getPreis()
    {
        return this.preis;
    }

    public void setPreis(double preis)
    {
        if (preis < 0)
        {
            throw new IllegalArgumentException("Preis muss ein positiver Wert oder 0 sein.");
        }

        this.preis = preis;
    }

    public String getNummer()
    {
        return this.nummer;
    }

    public String getNormalisierteNummer()
    {
        if (this.nummer.length() == 12)
        {
            return this.nummer;
        }

        Matcher matcher = Ware.NUMMER_MUSTER.matcher(this.nummer);

        if (matcher.matches())
        {
            String vordereNummer = matcher.group(1);
            String hintereNummer = matcher.group(2);
            return String.format("DE-%s-%s", vordereNummer, hintereNummer);
        }

        throw new IllegalStateException("Warennummer entspricht weder dem alten noch dem neuen Muster für die Nummernvergabe.");
    }

    public String getBezeichnung()
    {
        return this.bezeichnung;
    }
}
