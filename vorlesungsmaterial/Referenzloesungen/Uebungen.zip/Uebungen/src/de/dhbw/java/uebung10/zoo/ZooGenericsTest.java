package de.dhbw.java.uebung10.zoo;

import java.util.ArrayList;
import java.util.List;

public class ZooGenericsTest
{
    public static void main(String[] args)
    {
        Eisbaer knut = new Eisbaer("Knuuut");
        Eisbaer lars = new Eisbaer("Lars"); // Knuts Vater

        Zoo<Eisbaer> zoo = new Zoo<Eisbaer>();

        zoo.fuegeHinzu(knut);
        zoo.fuegeHinzu(lars);

        // Achtung: der Tierarzt hat 2 Listen, eine nur für Eisbären
        // (von mehreren Zoos) und eine für alle Tiere dieses Zoos.
        // Beides soll funktionieren
        List<Eisbaer> eisbaerenListe = new ArrayList<>();
        zoo.schreibeAufListe(eisbaerenListe);

        List<Tier> allgemeineListe = new ArrayList<>();
        zoo.schreibeAufListe(allgemeineListe);

        for (Tier tier : allgemeineListe)
        {
            System.out.println(tier);
        }
    }
}
