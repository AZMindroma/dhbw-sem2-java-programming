package de.dhbw.java.uebung07.bruchzahl.ausbaustufe6;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BruchzahlJUnitTest
{
    private Bruchzahl test1;
    private Bruchzahl test2;

    @BeforeEach
    void setUp() throws Exception
    {
        test1 = new Bruchzahl(2, 3);
        test2 = new Bruchzahl(3, 2);
    }

    @Test
    void testAddiere()
    {
        Bruchzahl result = test1.addiere(test2);
        assertEquals(result.toString(), "(13, 6)");
    }

    @Test
    void testMultipliziere()
    {
        Bruchzahl result = test1.multipliziere(test2);
        assertEquals(result.toString(), "(1, 1)");
    }

    @Test
    void testSubtrahiere()
    {
        Bruchzahl result = test1.subtrahiere(test2);
        assertEquals(result.toString(), "(-5, 6)");
    }

    @Test
    void testDividiere()
    {
        Bruchzahl result = test1.dividiere(test2);
        assertEquals(result.toString(), "(4, 9)");
    }

    @Test
    void testNormiereZaehler()
    {
        Bruchzahl result = new Bruchzahl(5, 0);
        assertEquals(result.toString(), "(1, 0)");
        
        // Dieser Test offenbart, dass bislang offenbar bei dieser Art von Normierung
        // eine ArithmeticException auftreten würde. Vermutlich ist normiere() nicht
        // korrekt implementiert...
    }

    @Test
    void testNormiereNenner()
    {
        Bruchzahl result = new Bruchzahl(0, 5);
        assertEquals(result.toString(), "(0, 1)");
    }

    @Test
    void testNormiereKuerzen()
    {
        Bruchzahl result = new Bruchzahl(12, 6);
        assertEquals(result.toString(), "(2, 1)");
    }
}
