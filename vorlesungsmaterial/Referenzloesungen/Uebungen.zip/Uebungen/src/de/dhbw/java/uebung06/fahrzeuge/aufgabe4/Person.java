package de.dhbw.java.uebung06.fahrzeuge.aufgabe4;

public abstract class Person
{
}
