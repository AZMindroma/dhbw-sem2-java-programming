package de.dhbw.java.uebung08.warenbestellung.aufgabe6;

public class WareException extends RuntimeException
{
    public WareException(String message)
    {
        super(message);
    }
}
