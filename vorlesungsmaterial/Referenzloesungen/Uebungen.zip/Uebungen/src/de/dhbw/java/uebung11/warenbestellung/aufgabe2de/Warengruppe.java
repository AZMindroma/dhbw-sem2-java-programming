package de.dhbw.java.uebung11.warenbestellung.aufgabe2de;

public enum Warengruppe
{
    BEKLEIDUNG, WERKZEUG, FAHRRADBEDARF;
}
