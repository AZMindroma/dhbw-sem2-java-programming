package de.dhbw.java.uebung08.fahrzeuge;

public class Motorrad extends Fahrzeug
{
    public Motorrad(Fahrzeughalter halter)
    {
        super(halter, "Motorrad", 2);
    }
}
