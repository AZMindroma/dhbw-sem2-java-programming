package de.dhbw.java.uebung03.bruchzahl.ausbaustufe3;

public class Bruchzahl
{
    private long zaehler;
    private long nenner;

    public Bruchzahl(long zaehler, long nenner)
    {
        super();
        this.zaehler = zaehler;
        this.nenner = nenner;
        
        this.normiere();
    }

    public Bruchzahl addiere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.nenner + q.zaehler * this.nenner;
        long neuerNenner = this.nenner * q.nenner;

        return new Bruchzahl(neuerZaehler, neuerNenner);
    }

    public Bruchzahl multipliziere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.zaehler;
        long neuerNenner = this.nenner * q.nenner;

        return new Bruchzahl(neuerZaehler, neuerNenner);
    }

    public Bruchzahl subtrahiere(Bruchzahl q)
    {
        return this.addiere(q.bildeGegenwert());
    }

    public Bruchzahl dividiere(Bruchzahl q)
    {
        return this.multipliziere(q.bildeKehrwert());
    }

    private Bruchzahl bildeGegenwert()
    {
        return new Bruchzahl(-this.zaehler, this.nenner);
    }

    private Bruchzahl bildeKehrwert()
    {
        return new Bruchzahl(this.nenner, this.zaehler);
    }

    private Bruchzahl normiere()
    {
        if (this.nenner < 0)
        {
            this.zaehler *= -1;
            this.nenner *= -1;
        }

        if (this.zaehler == 0 && this.nenner != 0)
        {
            this.nenner = 1;
        }

        if (this.nenner == 0 && this.zaehler != 0)
        {
            this.zaehler = 1;
        }

        this.kuerze();

        return this;
    }

    private void kuerze()
    {
        long ggT = ggT(this.zaehler, this.nenner);
        this.zaehler /= ggT;
        this.nenner /= ggT;
    }

    private long ggT(long a, long b)
    {
        do
        {
            long rest = a % b;
            if (rest == 0)
            {
                return b;
            }

            a = b;
            b = rest;
        }
        while (true);
    }

    public void zeigeAn()
    {
        System.out.print("(" + this.zaehler + ", " + this.nenner + ")");
    }
}
