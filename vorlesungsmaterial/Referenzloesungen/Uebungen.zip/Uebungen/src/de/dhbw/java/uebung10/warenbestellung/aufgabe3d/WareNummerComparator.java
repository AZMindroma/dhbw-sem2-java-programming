package de.dhbw.java.uebung10.warenbestellung.aufgabe3d;

import java.util.Comparator;

public class WareNummerComparator implements Comparator<Ware>
{
    @Override
    public int compare(Ware w1, Ware w2)
    {
        return w1.getNummer().compareTo(w2.getNummer());
    }
}
