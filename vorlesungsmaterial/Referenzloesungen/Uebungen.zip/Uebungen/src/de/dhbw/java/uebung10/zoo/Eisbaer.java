package de.dhbw.java.uebung10.zoo;

public class Eisbaer extends Tier
{
    public Eisbaer(String name)
    {
        super(name);
    }
}
