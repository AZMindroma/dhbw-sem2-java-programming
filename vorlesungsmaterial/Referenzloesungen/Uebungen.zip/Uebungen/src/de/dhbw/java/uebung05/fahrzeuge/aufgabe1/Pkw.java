package de.dhbw.java.uebung05.fahrzeuge.aufgabe1;

public class Pkw extends Fahrzeug
{
    private int anzahlTueren;

    public Pkw(int anzahlRaeder, int anzahlTueren)
    {
        super("Pkw", anzahlRaeder);
        this.anzahlTueren = anzahlTueren;
    }
    
    public int getAnzahlTueren()
    {
        return this.anzahlTueren;
    }
}
