package de.dhbw.java.uebung09.fahrzeuge.aufgabe1;

public abstract class Person
{
}
