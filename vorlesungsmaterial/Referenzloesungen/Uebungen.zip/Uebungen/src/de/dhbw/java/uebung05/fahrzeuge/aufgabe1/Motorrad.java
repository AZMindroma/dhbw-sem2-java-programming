package de.dhbw.java.uebung05.fahrzeuge.aufgabe1;

public class Motorrad extends Fahrzeug
{
    public Motorrad()
    {
        super("Motorrad", 2);
    }
}
