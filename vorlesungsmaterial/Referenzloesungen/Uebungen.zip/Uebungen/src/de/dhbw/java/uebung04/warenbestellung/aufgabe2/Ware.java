package de.dhbw.java.uebung04.warenbestellung.aufgabe2;

public class Ware
{
    private String nummer;
    private String bezeichnung;
    private double preis;

    public Ware(String nummer, String bezeichnung, double preis)
    {
        super();
        this.nummer = nummer;
        this.bezeichnung = bezeichnung;
        this.preis = preis;
    }

    public double getPreis()
    {
        return this.preis;
    }

    public void setPreis(double preis)
    {
        this.preis = preis;
    }

    public String getNummer()
    {
        return this.nummer;
    }

    public String getBezeichnung()
    {
        return this.bezeichnung;
    }
}
