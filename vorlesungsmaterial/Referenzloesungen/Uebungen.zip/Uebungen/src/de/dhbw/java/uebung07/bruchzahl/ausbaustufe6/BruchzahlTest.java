package de.dhbw.java.uebung07.bruchzahl.ausbaustufe6;

public class BruchzahlTest
{

    public static void main(String[] args)
    {
        Bruchzahl b1 = new Bruchzahl(5,7);
        Bruchzahl b2 = new Bruchzahl(3,5);
        
        Bruchzahl add = b1.addiere(b2);
        Bruchzahl mul = b1.multipliziere(b2);
        Bruchzahl sub = b1.subtrahiere(b2);
        Bruchzahl div = b1.dividiere(b2);
        
        System.out.println("Erste Bruchzahl: " + b1);
        System.out.println("Zweite Bruchzahl: " + b2);
        
        System.out.println(b1 + " + " + b2 + " = " + add);
        System.out.println(b1 + " - " + b2 + " = " + sub);
        System.out.println(b1 + " * " + b2 + " = " + mul);
        System.out.println(b1 + " / " + b2 + " = " + div);
        
        Bruchzahl b3 = new Bruchzahl(4, 35); // analog zu b1-b2
        System.out.println(b3.equals(sub)); // sollte true ergeben
        System.out.println(sub.equals(b3)); // sollte auch true ergeben
        System.out.println(b3.equals(b2)); // sollte false ergeben
        System.out.println(b3.equals(null)); // sollte false ergeben
    }
}
