package de.dhbw.java.uebung03.bruchzahl.ausbaustufe2;

public class Bruchzahl
{
    private long zaehler;
    private long nenner;
    
    public Bruchzahl(long zaehler, long nenner)
    {
        super();
        this.zaehler = zaehler;
        this.nenner = nenner;
    }
    
    public Bruchzahl addiere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.nenner + q.zaehler * this.nenner;
        long neuerNenner = this.nenner * q.nenner;
        
        return new Bruchzahl(neuerZaehler, neuerNenner);
    }
    
    public Bruchzahl multipliziere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.zaehler;
        long neuerNenner = this.nenner * q.nenner;
        
        return new Bruchzahl(neuerZaehler, neuerNenner);
    }
    
    public Bruchzahl subtrahiere(Bruchzahl q)
    {
        return this.addiere(q.bildeGegenwert());
    }
    
    public Bruchzahl dividiere(Bruchzahl q)
    {
        return this.multipliziere(q.bildeKehrwert());
    }
    
    private Bruchzahl bildeGegenwert()
    {
        return new Bruchzahl(-this.zaehler, this.nenner);
    }
    
    private Bruchzahl bildeKehrwert()
    {
        return new Bruchzahl(this.nenner, this.zaehler);
    }
    
    public void zeigeAn()
    {
        System.out.print("(" + this.zaehler + ", " + this.nenner + ")");
    }
}
