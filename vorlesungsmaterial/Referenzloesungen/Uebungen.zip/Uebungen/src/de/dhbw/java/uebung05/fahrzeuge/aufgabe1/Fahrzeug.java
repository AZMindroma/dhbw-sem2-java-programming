package de.dhbw.java.uebung05.fahrzeuge.aufgabe1;

public class Fahrzeug
{
    private String fahrzeugart;
    private int    anzahlRaeder;

    public Fahrzeug(String fahrzeugart, int anzahlRaeder)
    {
        super();
        this.fahrzeugart = fahrzeugart;
        this.anzahlRaeder = anzahlRaeder;
    }

    public Fahrzeug(int anzahlRaeder)
    {
        this("allgemeines Fahrzeug", anzahlRaeder);
    }

    public String getFahrzeugart()
    {
        return this.fahrzeugart;
    }

    public int getAnzahlRaeder()
    {
        return this.anzahlRaeder;
    }
}
