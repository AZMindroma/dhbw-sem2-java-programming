package de.dhbw.java.uebung08.warenbestellung.aufgabe6;

public class BezeichnungException extends WareException
{
    public BezeichnungException()
    {
        super("Unerlaubte Bezeichnung. Bezeichnung ist entweder null oder leer.");
    }
}
