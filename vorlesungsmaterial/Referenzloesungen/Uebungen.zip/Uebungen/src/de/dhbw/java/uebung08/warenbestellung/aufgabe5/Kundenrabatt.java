package de.dhbw.java.uebung08.warenbestellung.aufgabe5;

public class Kundenrabatt
{
    private static double rabattsatz = 0.05;

    public static void setRabattsatz(double rabattsatz)
    {
        Kundenrabatt.rabattsatz = rabattsatz;
    }

    public static double getRabattsatz()
    {
        return Kundenrabatt.rabattsatz;
    }

    public static double berechneRabattpreis(double vollerPreis)
    {
        double rabattPreis = vollerPreis * (1 - Kundenrabatt.rabattsatz);
        return rabattPreis;
    }
}
