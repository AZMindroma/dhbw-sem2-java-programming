package de.dhbw.java.uebung11.dateisystem.aufgabe4b;

public class DateisucheTest
{
    public static void main(String[] args)
    {
        // Wenn Sie nicht wissen, wie man in Ihrer IDE Kommandozeilenparameter eingibt,
        // können Sie folgenden Workaround verwenden:

        Dateisuche.main(new String[] { ".", "java" });
    }
}
