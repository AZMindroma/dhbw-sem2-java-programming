package de.dhbw.java.uebung10.zoo;

public class Tier
{
    private String name;

    public Tier(String name)
    {
        super();
        this.name = name;
    }
    
    @Override
    public String toString()
    {
        return this.name;
    }
}
