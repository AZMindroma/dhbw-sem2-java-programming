package de.dhbw.java.uebung06.fahrzeuge.aufgabe2;

public class Fahrzeughalter
{
    private String name;
    private Fahrzeug fahrzeug;
    
    public Fahrzeughalter(String name)
    {
        super();
        this.name = name;
    }
    
    public void setFahrzeug(Fahrzeug fahrzeug)
    {
        this.fahrzeug = fahrzeug;
    }
    
    public Fahrzeug getFahrzeug()
    {
        return this.fahrzeug;
    }
    
    @Override
    public String toString()
    {
        return this.name;
    }
}
