package de.dhbw.java.uebung04.warenbestellung.aufgabe1;

public class Kunde
{
    private String  vorname;
    private String  nachname;
    private String  nummer;
    private boolean bekommtRabatt;

    public Kunde(String vorname, String nachname, String nummer)
    {
        super();
        this.vorname = vorname;
        this.nachname = nachname;
        this.nummer = nummer;
    }

    public String getVorname()
    {
        return this.vorname;
    }

    public void setVorname(String vorname)
    {
        this.vorname = vorname;
    }

    public String getNachname()
    {
        return this.nachname;
    }

    public void setNachname(String nachname)
    {
        this.nachname = nachname;
    }

    public String getNummer()
    {
        return this.nummer;
    }

    public void setNummer(String nummer)
    {
        this.nummer = nummer;
    }

    public boolean getBekommtRabatt()
    {
        return this.bekommtRabatt;
    }

    public void setBekommtRabatt(boolean bekommtRabatt)
    {
        this.bekommtRabatt = bekommtRabatt;
    }
}
