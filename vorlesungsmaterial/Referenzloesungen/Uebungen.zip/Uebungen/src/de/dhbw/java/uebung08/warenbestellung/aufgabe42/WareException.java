package de.dhbw.java.uebung08.warenbestellung.aufgabe42;

public class WareException extends RuntimeException
{
    public WareException(String message)
    {
        super(message);
    }
}
