package de.dhbw.java.uebung10.warenbestellung.aufgabe3ab;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ware
{
    private static final Pattern NUMMER_MUSTER = Pattern.compile("(\\d{4})(\\d{4})");

    private String               nummer;
    private String               bezeichnung;
    private double               preis;

    public Ware(String nummer, String bezeichnung, double preis)
    {
        super();
        this.nummer = nummer;
        this.bezeichnung = bezeichnung;
        this.preis = preis;
    }

    public double getPreis()
    {
        return this.preis;
    }

    public void setPreis(double preis)
    {
        this.preis = preis;
    }

    public String getNummer()
    {
        return this.nummer;
    }

    public String getNormalisierteNummer()
    {
        if (this.nummer.length() == 12)
        {
            return this.nummer;
        }

        Matcher matcher = NUMMER_MUSTER.matcher(nummer);

        if (matcher.matches())
        {
            String vordereNummer = matcher.group(1);
            String hintereNummer = matcher.group(2);
            return String.format("DE-%s-%s", vordereNummer, hintereNummer);
        }

        return this.nummer; // normalerweise würde man hier sich anders "wehren" (Stichwort: Exception), kommt später
    }

    public String getBezeichnung()
    {
        return this.bezeichnung;
    }
    
    @Override
    public String toString()
    {
        return String.format("%12s %15s %8.2f EUR", this.getNormalisierteNummer(), this.getBezeichnung(), this.getPreis());
    }
}
