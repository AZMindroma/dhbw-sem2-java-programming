package de.dhbw.java.uebung02;

public class Temperatur
{
    private final double NULLPUNKT = 273.15;
    private double temperaturInKelvin;

    public void setVonKelvin(double kelvin)
    {
        temperaturInKelvin = kelvin;
    }
    
    public double getInKelvin()
    {
        return temperaturInKelvin;
    }
    
    public void setVonCelsius(double celsius)
    {
        temperaturInKelvin = celsius + NULLPUNKT;
    }
    
    public double getInCelsius()
    {
        return temperaturInKelvin - NULLPUNKT;
    }
    
    public void setVonFahrenheit(double fahrenheit)
    {
        temperaturInKelvin = (fahrenheit - 32) * (5.0/9.0) + NULLPUNKT;
    }
    
    public double getInFahrenheit()
    {
        return 1.8 * (temperaturInKelvin - NULLPUNKT) + 32.0;
    }
    
    public void setVonReamur(double reamur)
    {
        temperaturInKelvin = reamur * (5.0/4.0) + NULLPUNKT;
    }
    
    public double getInReaumur()
    {
        return 0.8 * (temperaturInKelvin - NULLPUNKT);
    }
    
    public static void main(String[] args)
    {
        Temperatur temperatur = new Temperatur();
        
        temperatur.setVonCelsius(24.5);
        System.out.println("24.5°C sind umgerechnet:");
        System.out.println("°R : " + temperatur.getInReaumur());
        System.out.println("°F : " + temperatur.getInFahrenheit());
        System.out.println(" K : " + temperatur.getInKelvin());
        
        System.out.println();

        temperatur.setVonKelvin(300);
        System.out.println("300K sind umgerechnet:");
        System.out.println("°R : " + temperatur.getInReaumur());
        System.out.println("°F : " + temperatur.getInFahrenheit());
        System.out.println("°C : " + temperatur.getInCelsius());
        
        System.out.println();
        
        temperatur.setVonFahrenheit(32);
        System.out.println("32°F sind umgerechnet:");
        System.out.println("°R : " + temperatur.getInReaumur());
        System.out.println(" K : " + temperatur.getInKelvin());
        System.out.println("°C : " + temperatur.getInCelsius());
    }
}
