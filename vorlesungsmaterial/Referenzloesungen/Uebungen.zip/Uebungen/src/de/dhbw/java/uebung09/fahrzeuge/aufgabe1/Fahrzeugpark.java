package de.dhbw.java.uebung09.fahrzeuge.aufgabe1;

public class Fahrzeugpark
{
    private Fahrzeug[] fahrzeuge;
    
    public Fahrzeugpark()
    {
        this.fahrzeuge = new Fahrzeug[0]; // am Anfang passt kein Fahrzeug rein
    }
    
    public void add(Fahrzeug f)
    {
        int bisherigeGroesse = this.fahrzeuge.length;
        Fahrzeug[] neuesArray = new Fahrzeug[bisherigeGroesse + 1]; // neues, um 1 größeres Array bauen
        neuesArray[bisherigeGroesse] = f; // am Ende das neue Fahrzeug einfügen
        
        for (int i = 0; i < fahrzeuge.length; i++)
        {
            neuesArray[i] = fahrzeuge[i]; // alle anderen umkopieren
        }
        
        this.fahrzeuge = neuesArray; // und das alte Array ersetzen
    }
    
    public Fahrzeug[] getAll()
    {
        return this.fahrzeuge;
    }
}
