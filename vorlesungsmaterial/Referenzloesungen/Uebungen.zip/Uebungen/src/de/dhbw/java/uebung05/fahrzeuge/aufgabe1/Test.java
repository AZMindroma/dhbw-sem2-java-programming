package de.dhbw.java.uebung05.fahrzeuge.aufgabe1;

public class Test
{
    public static void main(String[] args)
    {
        Fahrzeug f = new Fahrzeug(16);
        Pkw p = new Pkw(4, 5);
        Motorrad m = new Motorrad();
        
        // das hier ist NICHT schön, wird in der nächsten Aufgabe geändert
        // warum ist es nicht schön? Code-Wiederholung (aka Redundanz)

        System.out.print("Das Fahrzeug ist ein ");
        System.out.print(f.getFahrzeugart());
        System.out.print(" mit ");
        System.out.print(f.getAnzahlRaeder() + " Rädern.");
        System.out.println();
        
        System.out.print("Das Fahrzeug ist ein ");
        System.out.print(p.getFahrzeugart());
        System.out.print(" mit ");
        System.out.print(p.getAnzahlRaeder() + " Rädern und ");
        System.out.print(p.getAnzahlTueren() + " Türen.");
        System.out.println();
        
        System.out.print("Das Fahrzeug ist ein ");
        System.out.print(m.getFahrzeugart());
        System.out.print(" mit ");
        System.out.print(m.getAnzahlRaeder() + " Rädern.");
        System.out.println();
    }
}
