package de.dhbw.java.uebung09.warenbestellung.aufgabe2;

public class Kundenrabatt
{
    private static double rabattsatz = 0.05;

    public static void setRabattsatz(double rabattsatz)
    {
        Kundenrabatt.rabattsatz = rabattsatz;
    }

    public static double getRabattsatz()
    {
        return rabattsatz;
    }

    public static double berechneRabattpreis(double vollerPreis)
    {
        double rabattPreis = vollerPreis * (1 - rabattsatz);
        return rabattPreis;
    }
}
