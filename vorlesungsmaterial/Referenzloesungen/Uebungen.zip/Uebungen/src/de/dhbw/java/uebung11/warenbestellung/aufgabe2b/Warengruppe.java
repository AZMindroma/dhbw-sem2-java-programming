package de.dhbw.java.uebung11.warenbestellung.aufgabe2b;

public enum Warengruppe
{
    BEKLEIDUNG, WERKZEUG, FAHRRADBEDARF;
}
