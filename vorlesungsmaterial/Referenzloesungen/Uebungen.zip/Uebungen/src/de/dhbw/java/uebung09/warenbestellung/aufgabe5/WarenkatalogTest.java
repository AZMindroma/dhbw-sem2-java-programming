package de.dhbw.java.uebung09.warenbestellung.aufgabe5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class WarenkatalogTest
{
    private Warenkatalog katalog;
    
    @BeforeEach
    public void fill()
    {
        Ware w;
        katalog = new Warenkatalog();
        
        w = new Ware("01019010", "Hammer", 19.00);
        katalog.fuegeWareEin(w);

        w = new Ware("01019020", "Zange", 17.00);
        katalog.fuegeWareEin(w);
        
        w = new Ware("01019030", "Schraubendreher", 12.00);
        katalog.fuegeWareEin(w);
        
        w = new Ware("03073073", "Reifen", 33.00);
        katalog.fuegeWareEin(w);
        
        w = new Ware("03073074", "Schlauch", 8.00);
        katalog.fuegeWareEin(w);
        
        w = new Ware("03073103", "Luftpumpe", 13.00);
        katalog.fuegeWareEin(w);
        
        w = new Ware("03073104", "Ersatzkette", 8.00);
        katalog.fuegeWareEin(w);
    }
    
    @Test
    public void testEinfuegen()
    {
        int vorher = this.katalog.anzahl();
        
        this.katalog.fuegeWareEin(new Ware("00000000", "Test", 0.0));
        
        int nachher = this.katalog.anzahl();
        
        assertTrue( nachher == vorher + 1 );
    }

    @Test
    public void testDoubletteEinfuegen()
    {
        int vorher = this.katalog.anzahl();
        
        this.katalog.fuegeWareEin(new Ware("03073103", "Luftpumpe", 13.0));
        
        int nachher = this.katalog.anzahl();
        
        assertEquals(vorher, nachher, "Eine Doublette sollte nicht die Anzahl an Elementen verändern.");
    }
    
    @Test
    public void testLoeschen()
    {
        int vorher = this.katalog.anzahl();
        
        this.katalog.entferneWare("03073103");
        
        int nachher = this.katalog.anzahl();
        
        assertTrue( nachher == vorher - 1 );
    }
    
    @Test
    public void testAbfragen()
    {
        Ware ware = this.katalog.gibWare("03073103");
        
        assertEquals("03073103", ware.getNummer());
    }
    
    @Test
    public void testDatenkonsistenz()
    {
        int anzahl = this.katalog.anzahl();
        
        int alleWaren = this.katalog.alleWaren().size();
        int alleWarenBezeichnung = this.katalog.alleWarenNachBezeichnung().size();
        int alleWarenPreis = this.katalog.alleWarenNachPreis().size();
        
        assertEquals(anzahl, alleWaren, "alleWaren() hat nicht die passende Größe");
        assertEquals(anzahl, alleWarenBezeichnung, "alleWarenNachBezeichnung() hat nicht die passende Größe");
        assertEquals(anzahl, alleWarenPreis, "alleWarenNachPreis() hat nicht die passende Größe");
        // Hier müsste ein Fehler entstehen :-) Warum?
    }
}
