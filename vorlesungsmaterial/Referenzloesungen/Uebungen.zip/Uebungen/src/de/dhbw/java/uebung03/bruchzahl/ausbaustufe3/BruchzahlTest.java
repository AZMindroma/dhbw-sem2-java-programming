package de.dhbw.java.uebung03.bruchzahl.ausbaustufe3;

public class BruchzahlTest
{

    public static void main(String[] args)
    {
        Bruchzahl b1 = new Bruchzahl(5,7);
        Bruchzahl b2 = new Bruchzahl(3,5);
        
        Bruchzahl add = b1.addiere(b2);
        Bruchzahl mul = b1.multipliziere(b2);
        Bruchzahl sub = b1.subtrahiere(b2);
        Bruchzahl div = b1.dividiere(b2);
        
        System.out.print("Erste Bruchzahl: ");
        b1.zeigeAn();
        System.out.println();
        
        System.out.print("Zweite Bruchzahl: ");
        b2.zeigeAn();
        System.out.println();
        
        b1.zeigeAn();
        System.out.print(" + ");
        b2.zeigeAn();
        System.out.print(" = ");
        add.zeigeAn();
        System.out.println();
        
        b1.zeigeAn();
        System.out.print(" - ");
        b2.zeigeAn();
        System.out.print(" = ");
        sub.zeigeAn();
        System.out.println();
        
        b1.zeigeAn();
        System.out.print(" * ");
        b2.zeigeAn();
        System.out.print(" = ");
        mul.zeigeAn();
        System.out.println();
        
        b1.zeigeAn();
        System.out.print(" / ");
        b2.zeigeAn();
        System.out.print(" = ");
        div.zeigeAn();
        System.out.println();
    }

}
