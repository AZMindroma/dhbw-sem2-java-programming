package de.dhbw.java.uebung03.bruchzahl.ausbaustufe1;

public class Bruchzahl
{
    private long zaehler;
    private long nenner;
    
    public Bruchzahl(long zaehler, long nenner)
    {
        super();
        this.zaehler = zaehler;
        this.nenner = nenner;
    }
    
    public Bruchzahl addiere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.nenner + q.zaehler * this.nenner;
        long neuerNenner = this.nenner * q.nenner;
        
        return new Bruchzahl(neuerZaehler, neuerNenner);
    }
    
    public Bruchzahl multipliziere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.zaehler;
        long neuerNenner = this.nenner * q.nenner;
        
        return new Bruchzahl(neuerZaehler, neuerNenner);
    }
    
    public void zeigeAn()
    {
        System.out.print("(" + this.zaehler + ", " + this.nenner + ")");
    }
}
