package de.dhbw.java.uebung10.warenbestellung.aufgabe4b;

public enum Sortierkriterium
{
    NACH_NUMMER, NACH_BEZEICHNUNG, NACH_PREIS;
}
