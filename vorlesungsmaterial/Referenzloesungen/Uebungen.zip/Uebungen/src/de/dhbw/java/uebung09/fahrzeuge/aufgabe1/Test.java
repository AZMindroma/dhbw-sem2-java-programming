package de.dhbw.java.uebung09.fahrzeuge.aufgabe1;

public class Test
{
    public static void main(String[] args)
    {
        Fahrzeughalter dagobert = new Firma("Dagobert Inc.");
        Fahrzeughalter donald = new NatuerlichePerson("Donald","Duck");
        
        Fahrzeughalter[] dieHalter = { dagobert, donald };
        
        Pkw pkw1 = new Pkw(dagobert, 4, 5);
        Pkw pkw2 = new Pkw(dagobert, 4, 3);
        Motorrad motorrad = new Motorrad(donald);
        
        Fahrzeug[] fahrzeuge = { pkw1, pkw2, motorrad };
        
        for (Fahrzeug fahrzeug : fahrzeuge)
        {
            System.out.printf("Das Fahrzeug ist ein %s und gehört %s.%n", fahrzeug, fahrzeug.getHalter());
        }
        
        System.out.println();
        
        for (Fahrzeughalter fahrzeughalter : dieHalter)
        {
            System.out.printf("Die Fahrzeuge von %s:%n", fahrzeughalter);
            for (Fahrzeug fahrzeug : fahrzeughalter.getFahrzeuge())
            {
                System.out.printf("  - ein %s%n", fahrzeug);
            }
        }
    }
}
