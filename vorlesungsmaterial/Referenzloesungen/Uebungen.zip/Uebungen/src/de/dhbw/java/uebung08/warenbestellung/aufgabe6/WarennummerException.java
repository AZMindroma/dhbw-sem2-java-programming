package de.dhbw.java.uebung08.warenbestellung.aufgabe6;

public class WarennummerException extends WareException
{
    public WarennummerException(String warennummer)
    {
        super("Warennummer '" + warennummer + "' ist entweder null, leer oder entspricht nicht dem erlaubten Schema");
    }
}
