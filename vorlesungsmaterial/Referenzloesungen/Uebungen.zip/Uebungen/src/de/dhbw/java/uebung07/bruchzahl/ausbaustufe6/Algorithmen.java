package de.dhbw.java.uebung07.bruchzahl.ausbaustufe6;

public class Algorithmen
{
    public static long ggT(long a, long b)
    {
        do
        {
            long rest = a % b;
            if (rest == 0)
            {
                return b;
            }

            a = b;
            b = rest;
        }
        while (true);
    }
}
