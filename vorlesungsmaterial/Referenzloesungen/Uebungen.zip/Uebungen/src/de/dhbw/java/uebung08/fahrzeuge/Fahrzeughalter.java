package de.dhbw.java.uebung08.fahrzeuge;

public interface Fahrzeughalter
{
    void setFahrzeug(Fahrzeug fahrzeug);

    Fahrzeug getFahrzeug();
}
