package de.dhbw.java.uebung05.bruchzahl.ausbaustufe5;

public class Algorithmen
{
    public static long ggT(long a, long b)
    {
        do
        {
            long rest = a % b;
            if (rest == 0)
            {
                return b;
            }

            a = b;
            b = rest;
        }
        while (true);
    }
}
