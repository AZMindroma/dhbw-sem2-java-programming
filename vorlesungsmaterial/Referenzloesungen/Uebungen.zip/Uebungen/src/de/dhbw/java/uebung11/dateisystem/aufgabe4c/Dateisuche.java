package de.dhbw.java.uebung11.dateisystem.aufgabe4c;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

public class Dateisuche
{
    public static void main(String[] args)
    {
        if (args.length != 2)
        {
            Dateisuche.printUsage();
            return;
        }

        String startverzeichnis = args[0];
        String dateiendung = args[1];

        Dateisuche.suche(startverzeichnis, dateiendung);
    }

    private static void suche(String startverzeichnis, final String dateiendung)
    {
        Path file = Paths.get(startverzeichnis).toAbsolutePath();

        try
        {
            Files.walkFileTree(file, new SimpleFileVisitor<Path>()
            {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException
                {
                    String dateiname = file.toString();
                    System.out.println(dateiname);

                    return FileVisitResult.CONTINUE;
                }
            });
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private static void printUsage()
    {
        System.out.println("Fehlende oder falsche Parameter.");
        System.out.println("Die Anwendung wird so gestartet:");
        System.out.println("  java -jar dateisuche.jar <startpfad> <dateiendung>");
    }
}
