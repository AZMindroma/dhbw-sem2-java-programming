package de.dhbw.java.uebung06.fahrzeuge.aufgabe4;

public class Test
{
    public static void main(String[] args)
    {
        Fahrzeughalter dagobert = new Firma("Dagobert Inc.");
        Fahrzeughalter donald = new NatuerlichePerson("Donald","Duck");
        
        Pkw pkw = new Pkw(dagobert, 4, 5);
        Motorrad motorrad = new Motorrad(donald);
        
        Fahrzeug[] fahrzeuge = { pkw, motorrad };
        
        for (Fahrzeug fahrzeug : fahrzeuge)
        {
            Fahrzeughalter halter = fahrzeug.getHalter();
            System.out.printf("Das Fahrzeug von %s ist ein %s.%n", halter, halter.getFahrzeug());
            System.out.printf("Dieses Fahrzeug ist ein %s. Es gehört %s.%n", fahrzeug, halter);
            System.out.println();
        }
    }
}
