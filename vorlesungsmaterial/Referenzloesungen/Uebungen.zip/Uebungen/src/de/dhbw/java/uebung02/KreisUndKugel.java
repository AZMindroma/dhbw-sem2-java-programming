package de.dhbw.java.uebung02;

public class KreisUndKugel
{
    public static void mainEinfach(String[] args)
    {
        // naivere (aber u.U. besser lesbare) Variante, in der die Formeln 1:1 übertragen werden
        
        final double PI = 3.14159;
        
        double radius = 2.5; // normalerweise würde dieser Wert vom Nutzer erfragt (Parameter)
        
        double umfangKreis = 2 * PI * radius;
        double flaecheKreis = PI * radius * radius;
        
        double oberflaecheKugel = 4 * PI * radius * radius;
        double volumenKugel = (4.0/3.0) * PI * radius * radius * radius;
        
        System.out.println("Für den Radius " + radius + " wurde folgendes berechnet:");
        System.out.println("Kreisumfang:     " + umfangKreis);
        System.out.println("Kreisfläche:     " + flaecheKreis);
        System.out.println("Kugeloberfläche: " + oberflaecheKugel);
        System.out.println("Kugelvolumen:    " + volumenKugel);
    }
    
    public static void main(String[] args)
    {
        // etwas raffiniertere Variante, bei der bereits berechnete Werte verwendet werden
        
        final double PI = 3.14159;
        
        double radius = 2.5; // normalerweise würde dieser Wert vom Nutzer erfragt (Parameter)
        
        double piRadius = PI * radius;
        
        double umfangKreis = 2 * piRadius;
        double flaecheKreis = piRadius * radius;
        
        double oberflaecheKugel = 4 * flaecheKreis;
        double volumenKugel = (oberflaecheKugel / 3.0) * radius;
        
        System.out.println("Für den Radius " + radius + " wurde folgendes berechnet:");
        System.out.println("Kreisumfang:     " + umfangKreis);
        System.out.println("Kreisfläche:     " + flaecheKreis);
        System.out.println("Kugeloberfläche: " + oberflaecheKugel);
        System.out.println("Kugelvolumen:    " + volumenKugel);
    }

}
