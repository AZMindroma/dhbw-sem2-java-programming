package de.dhbw.java.uebung04.warenbestellung.aufgabe2;

public class Bestellposition
{
    private Ware ware;
    private int  menge;

    public Bestellposition(Ware ware, int menge)
    {
        super();
        this.ware = ware;
        this.menge = menge;
    }

    public Ware getWare()
    {
        return this.ware;
    }

    public int getMenge()
    {
        return this.menge;
    }
}
