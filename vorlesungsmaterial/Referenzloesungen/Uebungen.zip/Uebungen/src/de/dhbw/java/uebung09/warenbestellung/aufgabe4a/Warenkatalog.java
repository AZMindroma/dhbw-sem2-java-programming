package de.dhbw.java.uebung09.warenbestellung.aufgabe4a;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Warenkatalog
{
    private Map waren;
    
    public Warenkatalog()
    {
        this.waren = new HashMap();
    }
    
    public void fuegeWareEin(Ware ware)
    {
        this.waren.put(ware.getNummer(), ware);
    }
    
    public void entferneWare(String warennummer)
    {
        this.waren.remove(warennummer);
    }
    
    public Ware gibWare(String warennummer)
    {
        return (Ware) this.waren.get(warennummer);
    }
    
    public int anzahl()
    {
        return this.waren.size();
    }
    
    public Collection alleWaren()
    {
        return this.waren.values();
    }
    
    public Collection alleWarennummern()
    {
        return this.waren.keySet();
    }
    
    public void zeigeKatalog()
    {
        for (Object wareObj : alleWaren())
        {
            Ware ware = (Ware) wareObj;
            
            System.out.printf("%12s %15s %8.2f EUR%n", ware.getNormalisierteNummer(), ware.getBezeichnung(), ware.getPreis());
        }
    }
}
