package de.dhbw.java.uebung05.bruchzahl.ausbaustufe5;

public class Bruchzahl
{
    private long zaehler;
    private long nenner;

    public Bruchzahl(long zaehler, long nenner)
    {
        super();
        this.zaehler = zaehler;
        this.nenner = nenner;

        this.normiere();
    }

    public Bruchzahl addiere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.nenner + q.zaehler * this.nenner;
        long neuerNenner = this.nenner * q.nenner;

        return new Bruchzahl(neuerZaehler, neuerNenner);
    }

    public Bruchzahl multipliziere(Bruchzahl q)
    {
        long neuerZaehler = this.zaehler * q.zaehler;
        long neuerNenner = this.nenner * q.nenner;

        return new Bruchzahl(neuerZaehler, neuerNenner);
    }

    public Bruchzahl subtrahiere(Bruchzahl q)
    {
        return this.addiere(q.bildeGegenwert());
    }

    public Bruchzahl dividiere(Bruchzahl q)
    {
        return this.multipliziere(q.bildeKehrwert());
    }

    private Bruchzahl bildeGegenwert()
    {
        return new Bruchzahl(-this.zaehler, this.nenner);
    }

    private Bruchzahl bildeKehrwert()
    {
        return new Bruchzahl(this.nenner, this.zaehler);
    }

    private Bruchzahl normiere()
    {
        if (this.nenner < 0)
        {
            this.zaehler *= -1;
            this.nenner *= -1;
        }

        if (this.zaehler == 0 && this.nenner != 0)
        {
            this.nenner = 1;
        }

        if (this.nenner == 0 && this.zaehler != 0)
        {
            this.zaehler = 1;
        }

        this.kuerze();

        return this;
    }

    private void kuerze()
    {
        long ggT = Algorithmen.ggT(this.zaehler, this.nenner);
        this.zaehler /= ggT;
        this.nenner /= ggT;
    }

    public String toString()
    {
        return String.format("(%d, %d)", this.zaehler, this.nenner);
    }
    
    @Override
    public boolean equals(Object obj)
    {
        // Aufgabe c) "Verletzen der Kriterien"
        // Einfach kann man das Kriterium o.equals(null) == false verletzen, indem man
        // die != null Abfrage entfernt. Dann wird eine Exception erzeugt.
        // Das Kriterium der Reflexion a.equals(b) == b.equals(a) ist deutlich schwerer
        // zu verletzen. Das geht nur, wenn man mehrere Attribute nur unter gewissen
        // Bedingungen in den Vergleich mit einbringt. Da wir hier nur 2 Attribute haben,
        // dürfte das schwer zu konstruieren sein.
        if (obj != null && obj instanceof Bruchzahl)
        {
            Bruchzahl that = (Bruchzahl) obj;
            return this.zaehler == that.zaehler && this.nenner == that.nenner;
        }
        
        return false;
    }
}
