package de.dhbw.java.uebung08.warenbestellung.aufgabe42;

public class PreisNegativException extends WareException
{
    public PreisNegativException(double preis)
    {
        super("Der Preis " + preis + " muss 0 oder positiv sein.");
    }
}
