package de.dhbw.java.uebung09.fahrzeuge.aufgabe3;

public abstract class Person
{
}
