package de.dhbw.java.uebung11.warenbestellung.aufgabe2f;

public enum Sortierkriterium
{
    NACH_NUMMER, NACH_BEZEICHNUNG, NACH_PREIS;
}
