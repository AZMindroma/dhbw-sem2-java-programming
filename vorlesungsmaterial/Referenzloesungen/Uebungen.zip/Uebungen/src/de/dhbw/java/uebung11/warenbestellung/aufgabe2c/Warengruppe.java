package de.dhbw.java.uebung11.warenbestellung.aufgabe2c;

public enum Warengruppe
{
    BEKLEIDUNG, WERKZEUG, FAHRRADBEDARF;
}
