package de.dhbw.java.uebung11.warenbestellung.aufgabe3a;

public enum Warengruppe
{
    BEKLEIDUNG, WERKZEUG, FAHRRADBEDARF;
}
