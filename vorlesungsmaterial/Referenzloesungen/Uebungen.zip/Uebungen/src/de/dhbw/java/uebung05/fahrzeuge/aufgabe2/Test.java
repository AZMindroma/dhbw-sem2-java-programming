package de.dhbw.java.uebung05.fahrzeuge.aufgabe2;

public class Test
{
    public static void main(String[] args)
    {
        Fahrzeug f = new Fahrzeug(16);
        Pkw p = new Pkw(4, 5);
        Motorrad m = new Motorrad();
        
        Fahrzeug[] fahrzeuge = { f, p, m };
        
        for (Fahrzeug fahrzeug : fahrzeuge)
        {
            System.out.printf("Das Fahrzeug ist ein %s.%n", fahrzeug);
        }
    }
}
