package de.dhbw.java.uebung09.warenbestellung.aufgabe2;

import java.util.ArrayList;
import java.util.Collection;

public class Bestellung
{
    private Collection              positionen;
    private Kunde                   kunde;

    private static final String[]   UEBERSCHRIFT_FORMAT = { "%12s %15s %15s %15s %11s%n", "%12s %15s %15s %11s%n" };
    private static final String[]   DATEN_FORMAT        = { "%12s %15s %15.2f %15.2f %11d%n", "%12s %15s %15.2f %11d%n" };

    private static final String[][] UEBERSCHRIFTEN      = { { "Nummer", "Bezeichnung", "Listenpreis", "Kundenpreis", "Menge" },
                                                            { "Nummer", "Bezeichnung", "Listenpreis", "Menge" } };

    private static final String     KUNDE_FORMAT        = "Bestellung von %s %s (KN %s) %s%n";

    public Bestellung(Kunde kunde)
    {
        this.kunde = kunde;
        this.positionen = new ArrayList(); // hier kann man wechselnde Collections testen
    }

    public void nimmAuf(Bestellposition pos)
    {
        this.positionen.add(pos);
    }

    public void zeigeAn()
    {
        String rabattKunde = "";

        if (this.kunde.getBekommtRabatt())
        {
            // in einem "guten" Programm, wäre dieser Teilstring auch eine Konstante oder in einer Datei
            rabattKunde = String.format("mit %2.1f%% Kundenrabatt", Kundenrabatt.getRabattsatz() * 100);
        }

        System.out.printf(KUNDE_FORMAT, kunde.getVorname(), kunde.getNachname(), kunde.getNummer(), rabattKunde);

        int index = this.kunde.getBekommtRabatt() ? 0 : 1; // nicht schön, aber derzeit nicht anders lösbar

        System.out.printf(UEBERSCHRIFT_FORMAT[index], (Object[]) UEBERSCHRIFTEN[index]);

        for (Object object : this.positionen)
        {
            Bestellposition bestellposition = (Bestellposition) object;
            
            // Hilfsvariablen, damit die Darstellungssyntax nicht zu lang wird
            Ware w = bestellposition.getWare();
            int menge = bestellposition.getMenge();

            Object[] daten = null;

            if (this.kunde.getBekommtRabatt())
            {
                double rabattPreis = Kundenrabatt.berechneRabattpreis(w.getPreis());
                daten = new Object[] { w.getNormalisierteNummer(), w.getBezeichnung(), w.getPreis(), rabattPreis, menge };
            }
            else
            {
                daten = new Object[] { w.getNormalisierteNummer(), w.getBezeichnung(), w.getPreis(), menge };
            }

            System.out.printf(DATEN_FORMAT[index], daten);
        }
    }
}
