package de.dhbw.java.uebung06.fahrzeuge.aufgabe4;

public interface Fahrzeughalter
{
    void setFahrzeug(Fahrzeug fahrzeug);

    Fahrzeug getFahrzeug();
}
