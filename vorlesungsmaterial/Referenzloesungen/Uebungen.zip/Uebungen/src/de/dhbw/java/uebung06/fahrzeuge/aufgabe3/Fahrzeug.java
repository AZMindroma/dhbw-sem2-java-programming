package de.dhbw.java.uebung06.fahrzeuge.aufgabe3;

public abstract class Fahrzeug
{
    private String fahrzeugart;
    private int    anzahlRaeder;
    private Fahrzeughalter halter;

    public Fahrzeug(Fahrzeughalter halter, String fahrzeugart, int anzahlRaeder)
    {
        super();
        this.fahrzeugart = fahrzeugart;
        this.anzahlRaeder = anzahlRaeder;
        this.halter = halter;
        this.halter.setFahrzeug(this);
    }
    
    // der 2. Konstruktor ist nun sinnlos und sollte entfernt werden
    // er war dafür da, direkt Objekte von Fahrzeug zu erzeugen
    
    public Fahrzeughalter getHalter()
    {
        return this.halter;
    }

    public String getFahrzeugart()
    {
        return this.fahrzeugart;
    }

    public int getAnzahlRaeder()
    {
        return this.anzahlRaeder;
    }
    
    @Override
    public String toString()
    {
        return this.fahrzeugart + " mit " + this.anzahlRaeder + " Rädern";
    }
}
