package de.dhbw.java.uebung02;

public class Sortieren
{
    public static void main(String[] args)
    {
        int[] zahlen = { 13, 4, 17, 5, 3, 2, 9, 11, 20, 1, 29 };
        
        // einfaches sortieren per "bubble sort"
        for (int i = 0; i < zahlen.length; i++)
        {
            for (int j = i; j < zahlen.length; j++)
            {
                if (zahlen[i] > zahlen[j]) // eine Zahl weiter vorne ist größer als eine Zahl weiter hinten...
                {
                    int zwischenablage = zahlen[i]; // ... dann vertauschen
                    zahlen[i] = zahlen[j];
                    zahlen[j] = zwischenablage;
                }
            }
        }
        
        System.out.println("Das sortierte Array: ");
        for (int zahl : zahlen)
        {
            System.out.print(zahl + " ");
        }
        System.out.println();
    }
}
