package de.dhbw.java.uebung10.warenbestellung.aufgabe2;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class Warenkatalog 
{
    private Map<String, Ware> waren;

    public Warenkatalog()
    {
        this.waren = new TreeMap<>();
    }

    public void fuegeWareEin(Ware ware)
    {
        this.waren.put(ware.getNummer(), ware);
    }

    public void entferneWare(String warennummer)
    {
        this.waren.remove(warennummer);
    }

    public Ware gibWare(String warennummer)
    {
        return this.waren.get(warennummer);
    }

    public int anzahl()
    {
        return this.waren.size();
    }

    public Collection<Ware> alleWaren()
    {
        return this.waren.values();
    }

    public Collection<String> alleWarennummern()
    {
        return this.waren.keySet();
    }

    public Collection<Ware> alleWarenNachBezeichnung()
    {
        TreeSet<Ware> warenNachBezeichnung = new TreeSet<>(new WareBezeichnungComparator());
        warenNachBezeichnung.addAll(alleWaren());
        return warenNachBezeichnung;
    }

    public Collection<Ware> alleWarenNachPreis()
    {
        TreeSet<Ware> warenNachBezeichnung = new TreeSet<>(new WarePreisComparator());
        warenNachBezeichnung.addAll(alleWaren());
        return warenNachBezeichnung;
    }
    
    public void zeigeKatalog()
    {
        for (Ware ware : alleWaren())
        {
            System.out.println(ware);
        }
    }

    public void zeigeKatalogNachBezeichnung()
    {
        for (Ware ware : alleWarenNachBezeichnung())
        {
            System.out.println(ware);
        }
    }

    public void zeigeKatalogNachPreis()
    {
        for (Ware ware : alleWarenNachPreis())
        {
            System.out.println(ware);
        }
    }
}
