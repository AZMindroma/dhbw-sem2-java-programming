package de.dhbw.java.uebung06.fahrzeuge.aufgabe3;

public abstract class Fahrzeughalter
{
    private Fahrzeug fahrzeug;
    
    public void setFahrzeug(Fahrzeug fahrzeug)
    {
        this.fahrzeug = fahrzeug;
    }
    
    public Fahrzeug getFahrzeug()
    {
        return this.fahrzeug;
    }
}
