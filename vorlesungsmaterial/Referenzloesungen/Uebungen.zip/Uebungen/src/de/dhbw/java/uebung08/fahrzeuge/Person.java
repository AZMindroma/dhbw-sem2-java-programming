package de.dhbw.java.uebung08.fahrzeuge;

public abstract class Person
{
}
