package de.dhbw.java.uebung03.warenbestellung;

public class Bestellung
{
    private Bestellposition[] positionen;
    
    public Bestellung()
    {
        this.positionen = new Bestellposition[20]; // erst einmal nur 20 Positionen möglich
    }

    public void nimmAuf(Bestellposition pos)
    {
        for (int i = 0; i < positionen.length; i++) // suche eine freie Position
        {
            if (this.positionen[i] == null) // noch nichts drin
            {
                this.positionen[i] = pos; // dann einfüllen
                return; // und fertig, auf keinen Fall Schleife weiterführen
                // alternativ: break;
            }
        }
        
    }

    public void zeigeAn()
    {
        for (Bestellposition bestellposition : positionen)
        {
            if (bestellposition == null)
            {
                return; // ab hier gibt es nichts mehr zu tun
            }
            
            // Hilfsvariablen, damit die Darstellungssyntax nicht zu lang wird
            Ware w = bestellposition.getWare();
            int menge = bestellposition.getMenge();
            
            System.out.println(w.getNummer() + " " + w.getBezeichnung() + ", Preis: " + w.getPreis() + " EUR, Menge: " + menge);
        }
    }
}
