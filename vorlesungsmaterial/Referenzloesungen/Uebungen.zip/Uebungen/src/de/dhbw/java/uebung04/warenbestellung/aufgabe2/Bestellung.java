package de.dhbw.java.uebung04.warenbestellung.aufgabe2;

public class Bestellung
{
    private Bestellposition[]       positionen;
    private Kunde                   kunde;

    private static final String[]   UEBERSCHRIFT_FORMAT = { "%8s %15s %15s %15s %11s%n", "%8s %15s %15s %11s%n" };
    private static final String[]   DATEN_FORMAT        = { "%8s %15s %15.2f %15.2f %11d%n", "%8s %15s %15.2f %11d%n" };

    private static final String[][] UEBERSCHRIFTEN      = { { "Nummer", "Bezeichnung", "Listenpreis", "Kundenpreis", "Menge" },
                                                            { "Nummer", "Bezeichnung", "Listenpreis", "Menge" } };

    private static final String     KUNDE_FORMAT        = "Bestellung von %s %s (KN %s) %s%n";

    public Bestellung(Kunde kunde)
    {
        this.kunde = kunde;
        this.positionen = new Bestellposition[20]; // erst einmal nur 20 Positionen möglich
    }

    public void nimmAuf(Bestellposition pos)
    {
        for (int i = 0; i < this.positionen.length; i++) // suche eine freie Position
        {
            if (this.positionen[i] == null) // noch nichts drin
            {
                this.positionen[i] = pos; // dann einfüllen
                return; // und fertig, auf keinen Fall Schleife weiterführen
                // alternativ: break;
            }
        }

    }

    public void zeigeAn()
    {
        String rabattKunde = "";

        if (this.kunde.getBekommtRabatt())
        {
            // in einem "guten" Programm, wäre dieser Teilstring auch eine Konstante oder in einer Datei
            rabattKunde = String.format("mit %2.1f%% Kundenrabatt", Kundenrabatt.getRabattsatz() * 100);
        }

        System.out.printf(KUNDE_FORMAT, kunde.getVorname(), kunde.getNachname(), kunde.getNummer(), rabattKunde);
        
        int index = this.kunde.getBekommtRabatt() ? 0 : 1; // nicht schön, aber derzeit nicht anders lösbar
        
        System.out.printf(UEBERSCHRIFT_FORMAT[index], (Object[]) UEBERSCHRIFTEN[index]);

        for (Bestellposition bestellposition : this.positionen)
        {
            if (bestellposition == null)
            {
                return; // ab hier gibt es nichts mehr zu tun
            }

            // Hilfsvariablen, damit die Darstellungssyntax nicht zu lang wird
            Ware w = bestellposition.getWare();
            int menge = bestellposition.getMenge();
            
            Object[] daten = null;

            if (this.kunde.getBekommtRabatt())
            {
                double rabattPreis = Kundenrabatt.berechneRabattpreis(w.getPreis());
                daten = new Object[] { w.getNummer(), w.getBezeichnung(), w.getPreis(), rabattPreis, menge };
            }
            else
            {
                daten = new Object[] { w.getNummer(), w.getBezeichnung(), w.getPreis(), menge };
            }
            
            // Alternativ könnte man über Filterung in der Formatschablone die Daten ausgeben.
            // Das würde aber bedeuten: der Rabattpreis muss immer ausgerechnet werden, nur
            // nutzt die Schablone den Wert oder nicht.
            // Bsp: "%1$8s %2$15s %3$15.2f %4$15.2f %5$11d%n" vs. "%1$8s %2$15s %3$15.2f %5$11d%n"
            // Würde diese Methode etwas vereinfachen (if entfällt).
            System.out.printf(DATEN_FORMAT[index], daten);
        }
    }
}
