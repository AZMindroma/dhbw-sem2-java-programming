package de.dhbw.java.uebung11.dateisystem.aufgabe4a;

import java.io.File;
import java.io.IOException;

public class Dateisuche
{
    public static void main(String[] args)
    {
        if (args.length != 2)
        {
            Dateisuche.printUsage();
            return;
        }

        String startverzeichnis = args[0];
        String dateiendung = args[1];

        Dateisuche.suche(startverzeichnis, dateiendung);
    }

    private static void suche(String startverzeichnis, String dateiendung)
    {
        File file = new File(startverzeichnis);

        if (!file.exists() || !file.isDirectory())
        {
            return;
        }

        File[] files = file.listFiles();

        for (File datei : files)
        {
            String pfad = null;
            try
            {
                pfad = datei.getCanonicalPath();
            }
            catch (IOException ignored)
            {
            }

            if (datei.isDirectory())
            {
                Dateisuche.suche(pfad, dateiendung);
            }
            else
            {
                if (pfad.endsWith(dateiendung))
                {
                    System.out.println(pfad);
                }
            }
        }

    }

    private static void printUsage()
    {
        System.out.println("Fehlende oder falsche Parameter.");
        System.out.println("Die Anwendung wird so gestartet:");
        System.out.println("  java -jar dateisuche.jar <startpfad> <dateiendung>");
    }
}
