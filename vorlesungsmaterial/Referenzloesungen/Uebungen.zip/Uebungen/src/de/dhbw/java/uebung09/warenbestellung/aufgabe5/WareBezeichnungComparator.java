package de.dhbw.java.uebung09.warenbestellung.aufgabe5;

import java.util.Comparator;

public class WareBezeichnungComparator implements Comparator
{
    @Override
    public int compare(Object o1, Object o2)
    {
        Ware w1 = (Ware) o1; // erzeugt eine ClassCastException, wenn es nicht passt
        Ware w2 = (Ware) o2; // das ist aber "according to spec" (siehe Java Dokumentation)

        return w1.getBezeichnung().compareTo(w2.getBezeichnung());
    }
}
