package de.dhbw.java.uebung11.warenbestellung.aufgabe3bc;

public enum Warengruppe
{
    BEKLEIDUNG, WERKZEUG, FAHRRADBEDARF;
}
