package de.dhbw.java.uebung10.warenbestellung.aufgabe3c;

import java.util.Comparator;

public class WareBezeichnungComparator implements Comparator<Ware>
{
    @Override
    public int compare(Ware w1, Ware w2)
    {
        return w1.getBezeichnung().compareTo(w2.getBezeichnung());
    }
}
