package de.dhbw.java.uebung06.fahrzeuge.aufgabe2;

public class Motorrad extends Fahrzeug
{
    public Motorrad(Fahrzeughalter halter)
    {
        super(halter, "Motorrad", 2);
    }
}
