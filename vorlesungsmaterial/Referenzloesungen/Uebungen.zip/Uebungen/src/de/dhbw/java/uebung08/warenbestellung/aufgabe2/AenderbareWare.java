package de.dhbw.java.uebung08.warenbestellung.aufgabe2;

public class AenderbareWare extends Ware
{
    public AenderbareWare(String nummer, String bezeichnung, double preis)
    {
        super(nummer, bezeichnung, preis);
    }

    public void setBezeichnung(String neueBezeichnung)
    {
        // hier ist das Problem:
        // this.bezeichnung = neueBezeichnung geht zunächst nicht, weil private und es keine
        // setter-Methoden gibt.
        // Lösung: Attribut wird protected.

        this.bezeichnung = neueBezeichnung;
    }
}
