package de.dhbw.java.uebung02;

public class KleinsteZahl
{
    public static void main(String[] args)
    {
        int[] zahlen = { 13, 4, 17, 5, 3, 2, 9, 11, 23, 1, 29 };
        
        int kleinsteZahl = zahlen[0]; // nimm erst einmal das erste Element
        
        for (int zahl : zahlen)
        {
            if (zahl < kleinsteZahl) // wenn ein anderes kleiner ist als das bisher gefundene...
            {
                kleinsteZahl = zahl; // ...nimm das
            }
        }
        
        System.out.println("Die gefundene kleinste Zahl ist " + kleinsteZahl);
    }
}
