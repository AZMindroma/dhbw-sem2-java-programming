package de.dhbw.java.uebung02;

public class Quersumme
{
    public static void main(String[] args)
    {
        int zahl = 74103;
        int zahlOriginal = zahl;
        
        int quersumme = 0;
        
        while (zahl != 0)
        {
            quersumme += zahl % 10;
            zahl /= 10;
        }
        
        System.out.println("Die Quersumme von " + zahlOriginal + " beträgt " + quersumme);
    }
}
