package de.dhbw.java.uebung02;

public class Kurzzeitwecker
{
    private int minuten;
    private int sekunden;
    private int zehntel;
    
    public void stelle(int neuMin, int neuSek, int neuZehntelSek)
    {
        minuten = neuMin;
        sekunden = neuSek;
        zehntel = neuZehntelSek;
    }
    
    public void ticke()
    {
        while (minuten != 0 || sekunden != 0 || zehntel != 0) // solange nicht alles bei 0 angekommen ist, laufe weiter
        {
            darstellen(); // aktuellen Wert auf der Konsole darstellen
            
            // Zeit herunterzählen
            zehntel--;
            if (zehntel < 0)
            {
                zehntel = 9;
                sekunden--;
                
                if (sekunden < 0)
                {
                    sekunden = 59;
                    minuten--;
                }
            }

            // Für etwas "Echtzeit-Feeling" kann man das hier reinnehmen
//            try
//            {
//                Thread.sleep(100);
//            }
//            catch (InterruptedException ignored)
//            {
//            }
        }
        
        darstellen();
        System.out.println("Die Zeit ist abgelaufen");
    }

    private void darstellen()
    {
        int minutenZehner = minuten / 10;
        int minutenEiner = minuten % 10;
        int sekundenZehner = sekunden / 10;
        int sekundenEiner = sekunden % 10;
        
        System.out.println("" + minutenZehner + minutenEiner + ":" + sekundenZehner + sekundenEiner + "," + zehntel);
    }
    
    public static void main(String[] args)
    {
        Kurzzeitwecker wecker = new Kurzzeitwecker();
        wecker.stelle(1, 12, 4);
        wecker.ticke();
    }
}
