package de.dhbw.java.uebung11.warenbestellung.aufgabe3a;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Warenkatalog implements Iterable<Ware>
{
    private Map<String, Ware>                                    waren;
    private List<Sortierkriterium>                               kriterien;

    private static final Map<Sortierkriterium, Comparator<Ware>> COMPARATORS;

    static
    {
        // Hier wird zu jedem Sortierkriterium der passende Comparator vorgehalten, so dass
        // a) generisch zugegriffen werden kann und
        // b) nicht jeder Zugriff ein neues Comparator-Objekt erzeugt.
        COMPARATORS = new HashMap<Sortierkriterium, Comparator<Ware>>();

        Warenkatalog.COMPARATORS.put(Sortierkriterium.NACH_PREIS, (w1, w2) -> Double.compare(w1.getPreis(), w2.getPreis()));
        Warenkatalog.COMPARATORS.put(Sortierkriterium.NACH_BEZEICHNUNG, (w1, w2) -> w1.getBezeichnung().compareTo(w2.getBezeichnung()));
        Warenkatalog.COMPARATORS.put(Sortierkriterium.NACH_NUMMER, (w1, w2) -> w1.getNummer().compareTo(w2.getNummer()));
    }

    public Warenkatalog()
    {
        this.waren = new TreeMap<>();
        this.kriterien = Arrays.asList(Sortierkriterium.NACH_NUMMER); // Default
    }

    public void fuegeWareEin(Ware ware)
    {
        this.waren.put(ware.getNummer(), ware);
    }

    public void entferneWare(String warennummer)
    {
        this.waren.remove(warennummer);
    }

    public Ware gibWare(String warennummer)
    {
        return this.waren.get(warennummer);
    }

    public int anzahl()
    {
        return this.waren.size();
    }

    public void erhoehePreise(double erhoehung, Predicate<Ware> bedingung)
    {
        this.waren.values().stream().filter(bedingung).forEach(w -> w.setPreis(w.getPreis() * (1 + erhoehung)));
    }

    public void setKriterium(Sortierkriterium... kriterien)
    {
        this.kriterien = Arrays.asList(kriterien);
    }

    public List<Ware> filtern(Predicate<Ware> filter)
    {
        return this.waren.values().stream().filter(filter).collect(Collectors.toList());
    }

    public List<String> alleBezeichnungen()
    {
        return this.waren.values().stream().map(w -> w.getBezeichnung()).distinct().collect(Collectors.toList());
    }

    public boolean warenVorhanden(Predicate<Ware> bedingung)
    {
        return this.waren.values().stream().anyMatch(bedingung);
    }

    public Map<Warengruppe, Integer> anzahlWarenJeWarengruppeKlassisch()
    {
        Map<Warengruppe, Integer> result = new HashMap<>();

        // Map für alle Gruppen vorbereiten
        for (Warengruppe gruppe : Warengruppe.values())
        {
            result.put(gruppe, 0);
        }

        // Jede Ware betrachten und die Anzahl erhöhen
        for (Ware ware : this.waren.values())
        {
            Warengruppe gruppe = ware.getGruppe();
            Integer anzahl = result.get(gruppe);
            anzahl++;
            result.put(gruppe, anzahl);
        }

        return result;
    }

    public Map<Warengruppe, Integer> anzahlWarenJeWarengruppe()
    {
        return this.waren.values().stream().collect(Collectors.groupingBy(w -> w.getGruppe(), Collectors.summingInt(w -> 1)));
        // schwer im einzelnen zu dokumentieren...

        // collect -> sammle den Stream wieder ein (hier in eine Map)
        // groupingBy -> hier wird klar, dass es eine Map ist, die nach dem Kriterium w -> w.getGruppe() gruppiert wird
        // summingInt -> für jedes gefundene Objekt w summiere die Zahl 1 auf den Map-Value

        // Der Ansatz mit Stream und Lambda ist insofern interessant, da er in einer Zeile alles erledigt
        // und prinzipiell parallelisierbar ist.
        // Intuitiv lesbar im Sinne einer imperativen, objektorientierten Programmiersprache dürfte aber
        // der "klassische" Code sein. Die Arbeit mit Lambda- und Stream-Ausdrücken muss mit Erfahrung und
        // täglicher Praxis gefüllt werden.

        // Interessant auch: möglicherweise ist diese Lösung hier für Sie LESBAR. Waren aber die Hinweise in
        // der Aufgabe, die die Methodensyntax gezeigt hat, hilfreich, oder sind solche Angaben nicht doch ein
        // Stück weit sehr komplex?
        //
        // public static <T, K, A, D> Collector<T, ?, Map<K, D>> groupingBy(Function<? super T, ? extends K> classifier,
        // Collector<? super T, A, D> downstream)
    }

    @Override
    public Iterator<Ware> iterator()
    {
        return this.alleWaren().iterator();
    }

    public Collection<Ware> alleWaren()
    {
        List<Ware> liste = new ArrayList<Ware>(this.waren.values());

        Comparator<Ware> comparator = this.getComparator();
        liste.sort(comparator);

        return liste;
    }

    private Comparator<Ware> getComparator()
    {
        Comparator<Ware> result = null;

        for (Sortierkriterium sortierkriterium : this.kriterien)
        {
            Comparator<Ware> comparator = Warenkatalog.COMPARATORS.get(sortierkriterium);
            if (result == null)
            {
                result = comparator;
            }
            else
            {
                result = result.thenComparing(comparator);
            }
        }

        return result;
    }

    public void save()
    {
        String userDir = System.getProperty("user.home");

        List<String> zeilen = new ArrayList<>();

        for (Ware ware : this.waren.values())
        {
            zeilen.add(ware.toString());
        }

        Path ausgabedatei = Paths.get(userDir, "katalog.txt");

        try
        {
            Files.write(ausgabedatei, zeilen);
            System.out.println("Datei erfolgreich geschrieben.");
        }
        catch (IOException e)
        {
            System.out.println("Es ist ein Problem bei der Dateierstellung aufgetreten.");
            e.printStackTrace();
        }
    }
}
