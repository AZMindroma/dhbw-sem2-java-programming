package de.dhbw.java.uebung08.warenbestellung.aufgabe41;

public class Test
{

    public static void main(String[] args)
    {
        Exception e1 = Test.test("", "bla", 5.0);
        Exception e2 = Test.test("0815", null, 5.0);
        Exception e3 = Test.test("0815", "bla", -5.0);

        System.out.println(e1.getMessage());
        System.out.println(e2.getMessage());
        System.out.println(e3.getMessage());

        try
        {
            Ware w = new Ware("0815", "Ohne gültige Warennummer", 0.0);
            String nummer = w.getNormalisierteNummer();
            System.out.println(nummer);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }

    }

    public static Exception test(String nummer, String bezeichnung, double preis)
    {
        try
        {
            new Ware(nummer, bezeichnung, preis);
            return null;
        }
        catch (Exception e)
        {
            return e;
        }
    }

}
