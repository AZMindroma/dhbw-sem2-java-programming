package de.dhbw.java.uebung10.warenbestellung.aufgabe3d;

import java.util.Comparator;

public class WarePreisComparator implements Comparator<Ware>
{
    @Override
    public int compare(Ware w1, Ware w2)
    {
        return Double.compare(w1.getPreis(),w2.getPreis());
    }
}
