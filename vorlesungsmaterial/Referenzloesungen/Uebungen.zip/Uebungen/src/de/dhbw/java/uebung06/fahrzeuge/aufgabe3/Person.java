package de.dhbw.java.uebung06.fahrzeuge.aufgabe3;

public class Person extends Fahrzeughalter
{
    private String vorname;
    private String nachname;

    public Person(String vorname, String nachname)
    {
        super();
        this.vorname = vorname;
        this.nachname = nachname;
    }

    @Override
    public String toString()
    {
        return String.format("%s %s", this.vorname, this.nachname);
    }
}
