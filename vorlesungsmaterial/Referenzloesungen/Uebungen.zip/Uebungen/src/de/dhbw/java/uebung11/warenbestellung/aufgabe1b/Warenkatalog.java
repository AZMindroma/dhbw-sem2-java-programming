package de.dhbw.java.uebung11.warenbestellung.aufgabe1b;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Warenkatalog implements Iterable<Ware>
{
    private Map<String, Ware>                                    waren;
    private List<Sortierkriterium>                               kriterien;

    private static final Map<Sortierkriterium, Comparator<Ware>> COMPARATORS;

    static
    {
        // Hier wird zu jedem Sortierkriterium der passende Comparator vorgehalten, so dass
        // a) generisch zugegriffen werden kann und
        // b) nicht jeder Zugriff ein neues Comparator-Objekt erzeugt.
        COMPARATORS = new HashMap<Sortierkriterium, Comparator<Ware>>();

        Warenkatalog.COMPARATORS.put(Sortierkriterium.NACH_PREIS, (w1, w2) -> Double.compare(w1.getPreis(), w2.getPreis()));
        Warenkatalog.COMPARATORS.put(Sortierkriterium.NACH_BEZEICHNUNG, (w1, w2) -> w1.getBezeichnung().compareTo(w2.getBezeichnung()));
        Warenkatalog.COMPARATORS.put(Sortierkriterium.NACH_NUMMER, (w1, w2) -> w1.getNummer().compareTo(w2.getNummer()));
    }

    public Warenkatalog()
    {
        this.waren = new TreeMap<>();
        this.kriterien = Arrays.asList(Sortierkriterium.NACH_NUMMER); // Default
    }

    public void fuegeWareEin(Ware ware)
    {
        this.waren.put(ware.getNummer(), ware);
    }

    public void entferneWare(String warennummer)
    {
        this.waren.remove(warennummer);
    }

    public Ware gibWare(String warennummer)
    {
        return this.waren.get(warennummer);
    }

    public int anzahl()
    {
        return this.waren.size();
    }

    public void erhoehePreise(double erhoehung)
    {
        this.waren.values().forEach(w -> w.setPreis(w.getPreis() * (1 + erhoehung)));
    }

    public void setKriterium(Sortierkriterium... kriterien)
    {
        this.kriterien = Arrays.asList(kriterien);
    }

    // Wenn Sie die folgenden Methoden mit der bisherigen Funktionalität vergleichen,
    // werden Sie feststellen:
    // - deutlich weniger Redundanz
    // - aber dafür deutlich mehr Flexibilität
    @Override
    public Iterator<Ware> iterator()
    {
        return this.alleWaren().iterator();
    }

    public Collection<Ware> alleWaren()
    {
        List<Ware> liste = new ArrayList<Ware>(this.waren.values());

        Comparator<Ware> comparator = this.getComparator();
        liste.sort(comparator);

        return liste;
    }

    private Comparator<Ware> getComparator()
    {
        Comparator<Ware> result = null;

        for (Sortierkriterium sortierkriterium : this.kriterien)
        {
            Comparator<Ware> comparator = Warenkatalog.COMPARATORS.get(sortierkriterium);
            if (result == null)
            {
                result = comparator;
            }
            else
            {
                result = result.thenComparing(comparator);
            }
        }

        return result;
    }
}
