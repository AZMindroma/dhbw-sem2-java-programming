package de.dhbw.java.uebung11.warenbestellung.aufgabe2f;

public enum Warengruppe
{
    BEKLEIDUNG, WERKZEUG, FAHRRADBEDARF;
}
