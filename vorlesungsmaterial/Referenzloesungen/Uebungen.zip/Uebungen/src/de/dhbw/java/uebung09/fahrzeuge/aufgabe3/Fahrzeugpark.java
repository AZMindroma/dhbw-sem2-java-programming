package de.dhbw.java.uebung09.fahrzeuge.aufgabe3;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Fahrzeugpark
{
    private Set fahrzeuge;
    
    public Fahrzeugpark()
    {
        this.fahrzeuge = new HashSet(); 
    }
    
    public void add(Fahrzeug f)
    {
        this.fahrzeuge.add(f);
    }
    
    public Collection getAll()
    {
        return this.fahrzeuge;
    }
}
