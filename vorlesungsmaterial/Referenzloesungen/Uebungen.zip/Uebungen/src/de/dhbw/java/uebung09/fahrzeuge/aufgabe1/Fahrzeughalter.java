package de.dhbw.java.uebung09.fahrzeuge.aufgabe1;

public interface Fahrzeughalter
{
    void addFahrzeug(Fahrzeug fahrzeug);

    Fahrzeug[] getFahrzeuge();
}
