package de.dhbw.java.uebung05.fahrzeuge.aufgabe2;

public class Pkw extends Fahrzeug
{
    private int anzahlTueren;

    public Pkw(int anzahlRaeder, int anzahlTueren)
    {
        super("Pkw", anzahlRaeder);
        this.anzahlTueren = anzahlTueren;
    }
    
    public int getAnzahlTueren()
    {
        return this.anzahlTueren;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " und " + this.anzahlTueren + " Türen";
    }
}
