package de.dhbw.java.uebung08.warenbestellung.aufgabe6;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class BeispielJUnitTest
{
    @Test
    void testWare()
    {
        // Wenn Sie mit JUnit 5 arbeiten, ist das Testen von Exceptions
        // auch möglich, aber nur über Java 8 Spracherweiterungen.
        // Eine einfache Möglichkeit besteht aber in diesem Trick:

        try
        {
            new Ware(null, null, -1);
            Assertions.fail("Exception wurde nicht geworfen.");
        }
        catch (WareException we)
        {
            // ignorieren, das passt -> Test läuft durch
            // wer es noch genauer haben will, kann auch WarennummerException fangen,
            // weil diese hier korrekterweise als erste geworfen werden müsste.
        }
        catch (Throwable alleAnderenExceptions)
        {
            Assertions.fail("Die falsche Exception wurde geworfen.");
        }
    }

}
